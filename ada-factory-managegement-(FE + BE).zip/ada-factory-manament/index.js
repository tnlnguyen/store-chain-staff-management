var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
};
function setStyle() {
    var style = getUrlParameter('logged_in');
    if (style == 1 || sessionStorage.getItem('username') != null) {
        var head = document.getElementsByTagName('HEAD')[0];  
        var link = document.createElement('link'); 
        
        link.rel = 'stylesheet';  
      
        link.type = 'text/css';

        link.media = 'screen';
      
        link.href = 'css/index_auth.css';
  
        head.appendChild(link);  
        
        afterLogin();
    }
    else {
        var head = document.getElementsByTagName('HEAD')[0];  
        var link = document.createElement('link'); 
  
        link.rel = 'stylesheet';  
      
        link.type = 'text/css'; 
        
        link.media = 'screen';
      
        link.href = 'css/index.css';  
  
        head.appendChild(link);  
    }
}
function getData() {
    $(document).ready(function() {
        $.ajax({
            url: 'http://localhost/ada-factory-manament/Backend/data_controller.php/getData/',
            method: 'GET',
            success: function (data) {
                    console.log(data);
                    Buildlist(data);
            }
        })
    })
}
function Buildlist(data) {
    for (var i = 0; i < data.length; i++) {
        new_div = document.createElement('div');
        new_img = document.createElement('img');
        new_p = document.createElement('p');
        new_button = document.createElement('button');
        new_a = document.createElement('a');

        new_div.className = "div";
        new_img.setAttribute('src',`data:image/png;base64,${data[i].hinhanh}`);
        new_p.textContent = data[i].mota;
        new_p.className = "title-name";
        new_button.textContent = "Xem chi tiết";
        new_button.className = "chi-tiet-button";
        new_a.href = `chi-tiet-san-pham.html?id=${data[i].mathietbi}`;
        new_a.append(new_button);

        new_div.append(new_img);
        new_div.append(new_p);
        new_div.append(new_a);

        document.getElementById("gridview").appendChild(new_div);
    }
}
function afterLogin() {
    if (sessionStorage.getItem('username') != null) {
        div = document.createElement('div');
        span = document.createElement('span');
        a = document.createElement('a');

        div.className = 'profile';
        span.textContent = sessionStorage.getItem('username');
        a.className = 'navbutton';
        a.href = 'index.html?log_out=1';
        a.textContent = 'Logout';

        div.append(span);
        div.append(a);

        document.getElementById("header").appendChild(div);
        console.log(sessionStorage.getItem('username'));
    }
    else {
        window.location.href = 'index.html';
    }
}
function logout() {
    var logout = getUrlParameter('log_out');
    if (logout == 1) {
        sessionStorage.removeItem('username');
        window.location.href = 'index.html';
    }
}
logout();
setStyle();
getData();