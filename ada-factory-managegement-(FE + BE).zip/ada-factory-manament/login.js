const login = () => {
    let xhr = new XMLHttpRequest();
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    var params = `username=${username}&password=${password}`;
    xhr.open('POST','http://localhost/ada-factory-manament/Backend/user_controller.php/login_request/',true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        if (xhr.status == 200) {
            window.location.href = 'index.html?logged_in=1';
            sessionStorage.setItem('username', username);
        }
        else if (xhr.status == 400) {
            alert("Wrong username or password");
        }
    }
    xhr.send(params);
}