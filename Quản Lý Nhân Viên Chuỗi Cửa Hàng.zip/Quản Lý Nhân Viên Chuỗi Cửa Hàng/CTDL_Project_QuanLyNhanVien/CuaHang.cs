﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CTDL_Project_QuanLyNhanVien
{
    public partial class CuaHang : Form
    {
        string flag;
        List dstam = new List();
        CH temp = new CH();
        CH xoa = new CH();
        DataTable data = new DataTable();
        public void GhiCH(List ch)
        {
            FileStream fs = new FileStream("..\\Output.txt", FileMode.Create);
            StreamWriter swrite = new StreamWriter(fs, Encoding.UTF8);
            if (ch.pHead != null)
            {
                CH temp = ch.pHead;
                while (temp != null)
                {
                    swrite.WriteLine(temp.sMacuahang);
                    swrite.WriteLine(temp.sSDTCH);
                    swrite.WriteLine(temp.sDiachi);
                    temp = temp.next;
                }
            }
            swrite.Flush();
            fs.Close();
        }
        public void DocCH()
        {
            StreamReader fp = new StreamReader("..\\Output.txt");
            string line;
            int dem = 1, kiemtra;
            CH tam = new CH();
            while ((line = fp.ReadLine())!=null)
            {
                kiemtra = 3 * (dem % 3) + 1;
                if (kiemtra == 4) tam.sMacuahang = line; 
                if (kiemtra == 7) tam.sSDTCH = line;
                if (kiemtra == 1) tam.sDiachi = line;
                if (dem % 3 == 0)
                {
                    dstam.Addtail(tam);
                    tam = new CH();
                }
                dem++;
            }
            fp.Close();
        }
        public void Khoitao()
        {               
            CH tam = dstam.pHead;
            while (tam!=null)
            {
                data.Rows.Add(tam.sMacuahang, tam.sSDTCH, tam.sDiachi);
                dgvCUAHANG.DataSource = data;
                dgvCUAHANG.RefreshEdit();
                tam = tam.next;
            }
        }
        public DataTable createtable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Mã cửa hàng");
            dt.Columns.Add("SĐT");
            dt.Columns.Add("Địa chỉ");
            return dt;
        }
        private void Block()
        {
            txtMACUAHANG.Enabled = txtSDT.Enabled = txtDC.Enabled = false;
            btnLUU.Enabled = false;
        }
        private void Unblock()
        {
            txtMACUAHANG.Enabled = txtSDT.Enabled = txtDC.Enabled = true;
        }
        public void GhiNV()
        {
            FileStream fnv = new FileStream("..\\OutputNV.txt", FileMode.Create);
            StreamWriter swrite = new StreamWriter(fnv, Encoding.UTF8);
            if (dstam.pHead != null)
            {
                CH tam = dstam.pHead;
                Linkedlist listghi = tam.ds.pHead;
                while (tam != null)
                {
                    int j = 0;
                    while (listghi != null)
                    {
                        swrite.WriteLine(tam.sMacuahang);
                        swrite.WriteLine(listghi.sManhanvien);
                        swrite.WriteLine(listghi.sTennhanvien);
                        swrite.WriteLine(listghi.ngaysinh);
                        swrite.WriteLine(listghi.sChucvu);
                        swrite.WriteLine(listghi.sTrinhdo);
                        swrite.WriteLine(listghi.sLoaihinh);
                        swrite.WriteLine(listghi.sCMND);
                        swrite.WriteLine(listghi.sGioitinh);
                        swrite.WriteLine(listghi.sSDT);
                        swrite.WriteLine(listghi.sNguyenquan);
                        swrite.WriteLine(listghi.sDC);
                        listghi = listghi.next;
                    }
                    tam = tam.next;
                }
                tam = new CH();
                listghi = new Linkedlist();
                swrite.Flush();
            }
            fnv.Close();      
        }
        public void DocNV()
        {

            StreamReader fp = new StreamReader("..\\OutputNV.txt");
            string line, temp = "";
            int dem = 1, kiemtra;
            Linkedlist tam = new Linkedlist();
            while ((line = fp.ReadLine()) != null)
            {
                kiemtra = 12 * (dem % 12) + 1;
                if (kiemtra == 13) temp = line;
                if (kiemtra == 25) tam.sManhanvien = line;
                if (kiemtra == 37) tam.sTennhanvien = line;
                if (kiemtra == 49) tam.ngaysinh = line;
                if (kiemtra == 61) tam.sChucvu = line;
                if (kiemtra == 73) tam.sTrinhdo = line;
                if (kiemtra == 85) tam.sLoaihinh = line;
                if (kiemtra == 97) tam.sCMND = line;
                if (kiemtra == 109) tam.sGioitinh = line;
                if (kiemtra == 121) tam.sSDT = line;
                if (kiemtra == 133) tam.sNguyenquan = line;
                if (kiemtra == 1) tam.sDC = line;
                if (dem % 12 == 0)
                {
                    CH pos = dstam.pHead;
                    CH cuahang = dstam.pHead;
                    while (cuahang.sMacuahang != temp) cuahang = cuahang.next;
                    dstam.pHead = cuahang;
                    dstam.pHead.ds.Addtail(tam);
                    dstam.pHead = pos;
                    tam = new Linkedlist();
                    cuahang = new CH();
                    pos = new CH();
                }
                dem++;
            }
            fp.Close();
        }
        public CuaHang()
        {
            InitializeComponent();
        }
        private void btnTHEM_Click(object sender, EventArgs e)
        {
            flag = "add";
            Unblock();
            txtMACUAHANG.Text = txtSDT.Text = txtDC.Text = "";
            btnTHEM.Enabled = btnSUA.Enabled = btnXOA.Enabled = false;
            btnLUU.Enabled = true;
        }

        private void CuaHang_FormClosing(object sender, FormClosingEventArgs e)
        {
            GhiCH(dstam);
            GhiNV();
        }

        private void btnLUU_Click(object sender, EventArgs e)
        {
            if (flag == "add")
            {
                CH demo = new CH();
                demo.sMacuahang = txtMACUAHANG.Text;
                demo.sSDTCH = txtSDT.Text;
                demo.sDiachi = txtDC.Text;
                dstam.Addtail(demo);
                data.Rows.Add(demo.sMacuahang, demo.sSDTCH, demo.sDiachi);
                dgvCUAHANG.DataSource = data;
                dgvCUAHANG.RefreshEdit();
            }
            if (flag == "edit")
            {
                CH tempxoa = dstam.pHead;
                dstam.pHead = temp;
                dstam.pHead.sMacuahang = txtMACUAHANG.Text;
                dstam.pHead.sSDTCH = txtSDT.Text;
                dstam.pHead.sDiachi = txtDC.Text;
                dstam.pHead = tempxoa;
                int index = dgvCUAHANG.CurrentCell.RowIndex;
                DataTable dt = (DataTable)dgvCUAHANG.DataSource;
                if (dt.Rows.Count > 0)
                {
                    dgvCUAHANG.Rows[index].Cells[0].Value = txtMACUAHANG.Text;
                    dgvCUAHANG.Rows[index].Cells[1].Value = txtSDT.Text;
                    dgvCUAHANG.Rows[index].Cells[2].Value = txtDC.Text;
                }
                dgvCUAHANG.RefreshEdit();
            }
            Block();
            btnTHEM.Enabled = btnXOA.Enabled = btnSUA.Enabled = true;
        }

        private void CuaHang_Load_1(object sender, EventArgs e)
        {
            data = createtable();
            DocCH();
            DocNV();
            Khoitao();
            dgvCUAHANG.RefreshEdit();
            Block();
            if (dstam.pHead == null) btnSUA.Enabled = btnXOA.Enabled = btnLUU.Enabled = false;
        }

        private void btnSUA_Click(object sender, EventArgs e)
        {
            flag = "edit";
            temp = dstam.pHead;
            while (temp.sMacuahang != txtMACUAHANG.Text) temp = temp.next;
            Unblock();
            btnTHEM.Enabled = btnSUA.Enabled = btnXOA.Enabled = false;
            btnLUU.Enabled = true;
        }

        private void btnXOA_Click(object sender, EventArgs e)
        {
            int check = 0;
            xoa = dstam.pHead;
            CH tailxoa = dstam.pTail;
            if (xoa.sMacuahang == txtMACUAHANG.Text) check = 1;
            else if (tailxoa.sMacuahang == txtMACUAHANG.Text)
            {
                while (xoa.next != tailxoa) xoa = xoa.next;
                check = 2;
            }
            if (check != 1 && check != 2)
            {
                while (xoa.next.sMacuahang != txtMACUAHANG.Text) xoa = xoa.next;
            }
            if (MessageBox.Show("Bạn có thật sự muốn xóa cửa hàng này?", "Thông Báo", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
            {
                if (check == 1)
                {
                    dstam.pHead = dstam.pHead.next;
                    DataGridViewRow index = dgvCUAHANG.CurrentRow;
                    dgvCUAHANG.Rows.Remove(index);
                }
                else if (check == 2)
                {
                    CH tam = dstam.pHead;
                    dstam.pHead = xoa;
                    dstam.pHead.next = null;
                    dstam.pTail = dstam.pHead;
                    dstam.pHead = tam;
                    DataGridViewRow index = dgvCUAHANG.CurrentRow;
                    dgvCUAHANG.Rows.Remove(index);
                }
                else
                {
                    CH tam = dstam.pHead;
                    dstam.pHead = xoa;
                    CH muonxoa = dstam.pHead.next;
                    dstam.pHead.next = muonxoa.next;
                    muonxoa = new CH();
                    dstam.pHead = tam;
                    DataGridViewRow index = dgvCUAHANG.CurrentRow;
                    dgvCUAHANG.Rows.Remove(index);
                }
                dgvCUAHANG.RefreshEdit();
            }
        }
        private void dgvCUAHANG_SelectionChanged(object sender, EventArgs e)
        {
            var cell = dgvCUAHANG.CurrentCell;
            if (cell != null)
            {
                int index = cell.RowIndex;
                DataTable data = (DataTable)dgvCUAHANG.DataSource;
                if (data != null && data.Rows.Count > 0)
                {
                    txtMACUAHANG.Text = dgvCUAHANG.Rows[index].Cells[0].Value.ToString();
                    txtSDT.Text = dgvCUAHANG.Rows[index].Cells[1].Value.ToString();
                    txtDC.Text = dgvCUAHANG.Rows[index].Cells[2].Value.ToString();
                }
            }
            else
            {
                txtMACUAHANG.Text = txtDC.Text = txtSDT.Text = "";
            }
        }

    }
}
