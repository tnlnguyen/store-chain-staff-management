﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CTDL_Project_QuanLyNhanVien
{
    public partial class LoginForm : Form
    {
        private List<string> Tendangnhap = new List<string>();
        private List<string> Matkhau = new List<string>();
        public LoginForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LoginForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(MessageBox.Show("Bạn có thật sự muốn thoát chương trình?","Thông Báo",MessageBoxButtons.YesNo)!=System.Windows.Forms.DialogResult.Yes)
            {
                e.Cancel = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string a = "admin";
            string b = "admin";
            this.Tendangnhap.Add(a);
            this.Matkhau.Add(b);
            int check = 0;
            foreach (string n in this.Tendangnhap)
            {
                if (textBox1.Text == n)
                {
                    foreach (string x in this.Matkhau)
                    {
                        if (textBox2.Text == x)
                        {
                            TableManager demo = new TableManager();
                            this.Hide();
                            demo.ShowDialog();
                            this.Show();
                            check = 1;
                        }
                    }
                }
            }
            if (check == 0) MessageBox.Show("Bạn đã nhập sai tên đăng nhập hoặc mật khẩu","Thông báo",MessageBoxButtons.OK);
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}