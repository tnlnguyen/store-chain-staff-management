﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CTDL_Project_QuanLyNhanVien
{
    public partial class TableManager : Form
    {
        struct Node
        {
            int info;
            
        };
        struct List
        {
            Node pHead;
            Node pTail;
        };
        public TableManager()
        {
            InitializeComponent();
        }

        private void hệThốngToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void phụCấpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox4_Click(sender, e);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void quảnLýToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            CuaHang demo = new CuaHang();
            this.Hide();
            demo.ShowDialog();
            this.Show();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
           
        }

        private void TableManager_Load(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            KhenThuong demo = new KhenThuong();
            this.Hide();
            demo.ShowDialog();
            this.Show();
        }
        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            NhanVien demo = new NhanVien();
            this.Hide();
            demo.ShowDialog();
            this.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            BangLuong demo = new BangLuong();
            this.Hide();
            demo.ShowDialog();
            this.Show();
        }

        private void chứcNăngPhụToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void thôngTinToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Copyright @ ManhNhanIT");
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            PhuCap demo = new PhuCap();
            demo.ShowDialog();
            this.Show();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            PhongBan demo = new PhongBan();
            this.Hide();
            demo.ShowDialog();
            this.Show();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            ChamCong demo = new ChamCong();
            this.Hide();
            demo.ShowDialog();
            this.Show();
        }

        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void phòngBanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label6_Click(sender,e);
        }

        private void nhânViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox1_Click_1(sender, e);
        }

        private void chấmCôngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label10_Click(sender, e);
        }

        private void bảngLươngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox3_Click(sender, e);
        }

        private void khenThưởngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label7_Click(sender, e);
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void TableManager_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
