﻿namespace CTDL_Project_QuanLyNhanVien
{
    partial class CuaHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtDC = new System.Windows.Forms.TextBox();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.lblDC = new System.Windows.Forms.Label();
            this.lblSDT = new System.Windows.Forms.Label();
            this.txtMACUAHANG = new System.Windows.Forms.TextBox();
            this.lblMACUAHANG = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dgvCUAHANG = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblCHUCNANG = new System.Windows.Forms.Label();
            this.btnLUU = new System.Windows.Forms.Button();
            this.btnXOA = new System.Windows.Forms.Button();
            this.btnSUA = new System.Windows.Forms.Button();
            this.btnTHEM = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCUAHANG)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtDC);
            this.panel1.Controls.Add(this.txtSDT);
            this.panel1.Controls.Add(this.lblDC);
            this.panel1.Controls.Add(this.lblSDT);
            this.panel1.Controls.Add(this.txtMACUAHANG);
            this.panel1.Controls.Add(this.lblMACUAHANG);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(11, 11);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1077, 577);
            this.panel1.TabIndex = 1;
            // 
            // txtDC
            // 
            this.txtDC.Location = new System.Drawing.Point(147, 196);
            this.txtDC.Margin = new System.Windows.Forms.Padding(2);
            this.txtDC.Name = "txtDC";
            this.txtDC.Size = new System.Drawing.Size(241, 22);
            this.txtDC.TabIndex = 9;
            // 
            // txtSDT
            // 
            this.txtSDT.Location = new System.Drawing.Point(147, 118);
            this.txtSDT.Margin = new System.Windows.Forms.Padding(2);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(241, 22);
            this.txtSDT.TabIndex = 8;
            // 
            // lblDC
            // 
            this.lblDC.AutoSize = true;
            this.lblDC.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDC.Location = new System.Drawing.Point(4, 197);
            this.lblDC.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDC.Name = "lblDC";
            this.lblDC.Size = new System.Drawing.Size(62, 19);
            this.lblDC.TabIndex = 7;
            this.lblDC.Text = "Địa chỉ";
            // 
            // lblSDT
            // 
            this.lblSDT.AutoSize = true;
            this.lblSDT.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSDT.Location = new System.Drawing.Point(4, 121);
            this.lblSDT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSDT.Name = "lblSDT";
            this.lblSDT.Size = new System.Drawing.Size(42, 19);
            this.lblSDT.TabIndex = 5;
            this.lblSDT.Text = "SĐT";
            // 
            // txtMACUAHANG
            // 
            this.txtMACUAHANG.Location = new System.Drawing.Point(147, 42);
            this.txtMACUAHANG.Margin = new System.Windows.Forms.Padding(2);
            this.txtMACUAHANG.Name = "txtMACUAHANG";
            this.txtMACUAHANG.Size = new System.Drawing.Size(241, 22);
            this.txtMACUAHANG.TabIndex = 4;
            // 
            // lblMACUAHANG
            // 
            this.lblMACUAHANG.AutoSize = true;
            this.lblMACUAHANG.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMACUAHANG.Location = new System.Drawing.Point(0, 42);
            this.lblMACUAHANG.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMACUAHANG.Name = "lblMACUAHANG";
            this.lblMACUAHANG.Size = new System.Drawing.Size(110, 19);
            this.lblMACUAHANG.TabIndex = 3;
            this.lblMACUAHANG.Text = "Mã cửa hàng";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dgvCUAHANG);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(406, 11);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(671, 527);
            this.panel3.TabIndex = 2;
            // 
            // dgvCUAHANG
            // 
            this.dgvCUAHANG.AllowUserToOrderColumns = true;
            this.dgvCUAHANG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCUAHANG.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            this.dgvCUAHANG.Location = new System.Drawing.Point(0, 0);
            this.dgvCUAHANG.Name = "dgvCUAHANG";
            this.dgvCUAHANG.RowTemplate.Height = 24;
            this.dgvCUAHANG.Size = new System.Drawing.Size(665, 527);
            this.dgvCUAHANG.TabIndex = 2;
            this.dgvCUAHANG.SelectionChanged += new System.EventHandler(this.dgvCUAHANG_SelectionChanged);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Mã cửa hàng";
            this.Column1.Frozen = true;
            this.Column1.HeaderText = "Mã cửa hàng";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 150;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "SĐT";
            this.Column2.Frozen = true;
            this.Column2.HeaderText = "SĐT";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 200;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "Địa chỉ";
            this.Column3.Frozen = true;
            this.Column3.HeaderText = "Địa chỉ";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 300;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 17);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 17);
            this.label1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblCHUCNANG);
            this.panel2.Controls.Add(this.btnLUU);
            this.panel2.Controls.Add(this.btnXOA);
            this.panel2.Controls.Add(this.btnSUA);
            this.panel2.Controls.Add(this.btnTHEM);
            this.panel2.Location = new System.Drawing.Point(17, 292);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(305, 218);
            this.panel2.TabIndex = 1;
            // 
            // lblCHUCNANG
            // 
            this.lblCHUCNANG.AutoSize = true;
            this.lblCHUCNANG.Location = new System.Drawing.Point(11, 12);
            this.lblCHUCNANG.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCHUCNANG.Name = "lblCHUCNANG";
            this.lblCHUCNANG.Size = new System.Drawing.Size(76, 17);
            this.lblCHUCNANG.TabIndex = 5;
            this.lblCHUCNANG.Text = "Chức năng";
            // 
            // btnLUU
            // 
            this.btnLUU.Location = new System.Drawing.Point(178, 138);
            this.btnLUU.Margin = new System.Windows.Forms.Padding(2);
            this.btnLUU.Name = "btnLUU";
            this.btnLUU.Size = new System.Drawing.Size(91, 58);
            this.btnLUU.TabIndex = 3;
            this.btnLUU.Text = "Lưu";
            this.btnLUU.UseVisualStyleBackColor = true;
            this.btnLUU.Click += new System.EventHandler(this.btnLUU_Click);
            // 
            // btnXOA
            // 
            this.btnXOA.Location = new System.Drawing.Point(25, 138);
            this.btnXOA.Margin = new System.Windows.Forms.Padding(2);
            this.btnXOA.Name = "btnXOA";
            this.btnXOA.Size = new System.Drawing.Size(91, 58);
            this.btnXOA.TabIndex = 2;
            this.btnXOA.Text = "Xóa";
            this.btnXOA.UseVisualStyleBackColor = true;
            this.btnXOA.Click += new System.EventHandler(this.btnXOA_Click);
            // 
            // btnSUA
            // 
            this.btnSUA.Location = new System.Drawing.Point(178, 48);
            this.btnSUA.Margin = new System.Windows.Forms.Padding(2);
            this.btnSUA.Name = "btnSUA";
            this.btnSUA.Size = new System.Drawing.Size(91, 65);
            this.btnSUA.TabIndex = 1;
            this.btnSUA.Text = "Sửa";
            this.btnSUA.UseVisualStyleBackColor = true;
            this.btnSUA.Click += new System.EventHandler(this.btnSUA_Click);
            // 
            // btnTHEM
            // 
            this.btnTHEM.Location = new System.Drawing.Point(24, 48);
            this.btnTHEM.Margin = new System.Windows.Forms.Padding(2);
            this.btnTHEM.Name = "btnTHEM";
            this.btnTHEM.Size = new System.Drawing.Size(92, 65);
            this.btnTHEM.TabIndex = 0;
            this.btnTHEM.Text = "Thêm";
            this.btnTHEM.UseVisualStyleBackColor = true;
            this.btnTHEM.Click += new System.EventHandler(this.btnTHEM_Click);
            // 
            // CuaHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1120, 604);
            this.Controls.Add(this.panel1);
            this.Name = "CuaHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cửa Hàng";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CuaHang_FormClosing);
            this.Load += new System.EventHandler(this.CuaHang_Load_1);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCUAHANG)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblDC;
        private System.Windows.Forms.Label lblSDT;
        private System.Windows.Forms.TextBox txtMACUAHANG;
        private System.Windows.Forms.Label lblMACUAHANG;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblCHUCNANG;
        private System.Windows.Forms.Button btnLUU;
        private System.Windows.Forms.Button btnXOA;
        private System.Windows.Forms.Button btnSUA;
        private System.Windows.Forms.Button btnTHEM;
        private System.Windows.Forms.DataGridView dgvCUAHANG;
        private System.Windows.Forms.TextBox txtDC;
        private System.Windows.Forms.TextBox txtSDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
    }
}