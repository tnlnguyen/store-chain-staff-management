﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CTDL_Project_QuanLyNhanVien
{
    public partial class NhanVien : Form
    {
        string flag;
        DataTable dtsv;
        List dstam = new List();
        CH sua = new CH();
        CH xoa = new CH();
        Linkedlist listsua = new Linkedlist();
        Linkedlist listxoa = new Linkedlist();
        Linkedlist dsxoatam = new Linkedlist();
        public NhanVien()
        {
            InitializeComponent();
        }
        public void Khoitaocombobox()
        {
            List<string> item = new List<string>();
            CH tamthoi = dstam.pHead;
            while (tamthoi != null)
            {
                item.Add(tamthoi.sMacuahang);
                tamthoi = tamthoi.next;
            }
            cbbMACUAHANG.DataSource = item;
        }
        public void Khoitao()
        {
            CH tamthoi = dstam.pHead;
            while (tamthoi!=null)
            {
                Linkedlist tamthoids = tamthoi.ds.pHead;
                while (tamthoids != null)
                {
                    dtsv.Rows.Add(tamthoids.sManhanvien, tamthoids.sTennhanvien, tamthoids.ngaysinh, tamthoi.sMacuahang, tamthoids.sChucvu, tamthoids.sTrinhdo, tamthoids.sLoaihinh, tamthoids.sCMND, tamthoids.sGioitinh, tamthoids.sSDT, tamthoids.sNguyenquan, tamthoids.sDC);
                    tamthoids = tamthoids.next;
                }
                tamthoids = new Linkedlist();
                tamthoi = tamthoi.next;
            }
            dgvNHANVIEN.DataSource = dtsv;
            dgvNHANVIEN.RefreshEdit();
        }
        public void GhiNV()
        {
            FileStream fnv = new FileStream("..\\OutputNV.txt", FileMode.Create);
            StreamWriter swrite = new StreamWriter(fnv, Encoding.UTF8);
            if (dstam.pHead != null)
            {
                CH tam = dstam.pHead;
                if (tam.ds.pHead != null)
                {
                    while (tam != null)
                    {
                        Linkedlist listghi = tam.ds.pHead;
                        while (listghi != null)
                        {
                            swrite.WriteLine(tam.sMacuahang);
                            swrite.WriteLine(listghi.sManhanvien);
                            swrite.WriteLine(listghi.sTennhanvien);
                            swrite.WriteLine(listghi.ngaysinh);
                            swrite.WriteLine(listghi.sChucvu);
                            swrite.WriteLine(listghi.sTrinhdo);
                            swrite.WriteLine(listghi.sLoaihinh);
                            swrite.WriteLine(listghi.sCMND);
                            swrite.WriteLine(listghi.sGioitinh);
                            swrite.WriteLine(listghi.sSDT);
                            swrite.WriteLine(listghi.sNguyenquan);
                            swrite.WriteLine(listghi.sDC);
                            listghi = listghi.next;
                        }
                        tam = tam.next;
                    }
                }
            }
            swrite.Flush();
            fnv.Close();
        }
        public void DocNV()
        {
            StreamReader fp = new StreamReader("..\\OutputNV.txt");
            string line, temp = "";
            int dem = 1, kiemtra;
            Linkedlist tam = new Linkedlist();
            while ((line = fp.ReadLine()) != null)
            {
                
                kiemtra = 12 * (dem % 12) + 1;
                if (kiemtra == 13) temp = line;
                if (kiemtra == 25) tam.sManhanvien = line;
                if (kiemtra == 37) tam.sTennhanvien = line;
                if (kiemtra == 49) tam.ngaysinh = line;
                if (kiemtra == 61) tam.sChucvu = line;
                if (kiemtra == 73) tam.sTrinhdo = line;
                if (kiemtra == 85) tam.sLoaihinh = line;
                if (kiemtra == 97) tam.sCMND = line;
                if (kiemtra == 109) tam.sGioitinh = line;
                if (kiemtra == 121) tam.sSDT = line;
                if (kiemtra == 133) tam.sNguyenquan = line;
                if (kiemtra == 1) tam.sDC = line;
                if (dem % 12 == 0)
                {
                    CH pos = dstam.pHead;
                    CH cuahang = dstam.pHead;
                    while (cuahang.sMacuahang != temp) cuahang = cuahang.next;
                    dstam.pHead = cuahang;
                    dstam.pHead.ds.Addtail(tam);
                    dstam.pHead = pos;
                    tam = new Linkedlist();
                    cuahang = new CH();
                    pos = new CH();
                }
                dem++;
            }
            fp.Close();
        }
        public void DocCH()
        {
            StreamReader fp = new StreamReader("..\\Output.txt");
            string line;
            int dem = 1, kiemtra;
            CH tam = new CH();
            while ((line = fp.ReadLine()) != null)
            {
                kiemtra = 3 * (dem % 3) + 1;
                if (kiemtra == 4) tam.sMacuahang = line;
                if (kiemtra == 7) tam.sSDTCH = line;
                if (kiemtra == 1) tam.sDiachi = line;
                if (dem % 3 == 0)
                {
                    dstam.Addtail(tam);
                    tam = new CH();   
                }
                dem++;
            }
            fp.Close();
        }
        public DataTable createtable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Mã nhân viên");
            dt.Columns.Add("Họ và tên");
            dt.Columns.Add("Ngày sinh");
            dt.Columns.Add("Mã cửa hàng");
            dt.Columns.Add("Chức vụ");
            dt.Columns.Add("Trình Độ");
            dt.Columns.Add("Loại hình");
            dt.Columns.Add("CMND/CMT");
            dt.Columns.Add("Giới tính");
            dt.Columns.Add("SĐT");
            dt.Columns.Add("Nguyên Quán");
            dt.Columns.Add("ĐC Thường Trú");
            return dt;
        }
        private void Block()
        {
            txtMANV.Enabled = false;
            txtHOTEN.Enabled = false;
            txtNGAYSINH.Enabled = false;
            cbbMACUAHANG.Enabled = false;
            txtCHUCVU.Enabled = false;
            txtTRINHDO.Enabled = false;
            txtLOAIHINH.Enabled = false;
            txtGIOITINH.Enabled = false;
            txtSDT.Enabled = false;
            txtNGUYENQUAN.Enabled = false;
            txtDC.Enabled = false;
            txtCMND.Enabled = false;
            btnLUU.Enabled = false;

        }
        private void Unblock()
        {
            txtMANV.Enabled = true;
            txtHOTEN.Enabled = true;
            txtNGAYSINH.Enabled = true;
            cbbMACUAHANG.Enabled = true;
            txtCHUCVU.Enabled = true;
            txtTRINHDO.Enabled = true;
            txtLOAIHINH.Enabled = true;
            txtGIOITINH.Enabled = true;
            txtSDT.Enabled = true;
            txtNGUYENQUAN.Enabled = true;
            txtDC.Enabled = true;
            txtCMND.Enabled = true;
            btnLUU.Enabled = true;
        }
        private void NhanVien_Load(object sender, EventArgs e)
        {
            dtsv = createtable();
            DocCH();
            DocNV();
            Khoitao();
            Khoitaocombobox();
            Block();
            if (dstam.pHead == null) btnSUA.Enabled = btnXOA.Enabled = btnLUU.Enabled = false;
        }
        private void btnSUA_Click(object sender, EventArgs e)
        {
            flag = "edit";
            sua = dstam.pHead;
            while (sua.sMacuahang != cbbMACUAHANG.Text) sua = sua.next;
            listsua = sua.ds.pHead;
            while (listsua.sManhanvien != txtMANV.Text) listsua = listsua.next;
            Unblock();
            btnTHEM.Enabled = btnSUA.Enabled = btnXOA.Enabled = false;
        }

        private void btnTHEM_Click(object sender, EventArgs e)
        {
            flag = "add";
            btnTHEM.Enabled = false;
            btnSUA.Enabled = false;
            btnXOA.Enabled = false;
            Unblock();
            txtMANV.Text = "";
            txtHOTEN.Text = "";
            txtNGAYSINH.Text = "";
            cbbMACUAHANG.Text = "";
            txtCHUCVU.Text = "";
            txtTRINHDO.Text = "";
            txtLOAIHINH.Text = "";
            txtGIOITINH.Text = "";
            txtSDT.Text = "";
            txtNGUYENQUAN.Text = "";
            txtDC.Text = "";
            txtCMND.Text = "";
        }

        private void btnXOA_Click(object sender, EventArgs e)
        {
            int checkxoa = 0;
            xoa = dstam.pHead;
            while (xoa != null && xoa.sMacuahang != cbbMACUAHANG.Text) xoa = xoa.next;
            listxoa = xoa.ds.pHead;
            if (listxoa.sManhanvien == txtMANV.Text) checkxoa = 1;
            else if (xoa.ds.pTail.sManhanvien == txtMANV.Text)
            {
                dsxoatam = xoa.ds.pHead;
                while (dsxoatam.next.sManhanvien != txtMANV.Text) dsxoatam = dsxoatam.next;
                checkxoa = 2; 		
            }
            if (checkxoa != 1 && checkxoa != 2) while (listxoa.next.sManhanvien != txtMANV.Text) listxoa = listxoa.next;

            if (MessageBox.Show("Bạn có thật sự muốn xóa nhân viên này?", "Thông Báo", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
            {
                if (checkxoa == 1)
                {
                    CH listxoatam1 = dstam.pHead;
                    Linkedlist listxoatam2 = dstam.pHead.ds.pHead;
                    dstam.pHead = xoa;
                    if (dstam.pHead.ds.pTail == dstam.pHead.ds.pHead) dstam.pHead.ds.pHead = dstam.pHead.ds.pTail = null;
                    else dstam.pHead.ds.pHead = dstam.pHead.ds.pHead.next;
                    dstam.pHead = listxoatam1;
                    dstam.pHead.ds.pHead = listxoatam2;
                    DataGridViewRow index = dgvNHANVIEN.CurrentRow;
                    dgvNHANVIEN.Rows.Remove(index);
                }
                else if (checkxoa == 2) 
                {
                    CH listxoatam1 = dstam.pHead;
                    Linkedlist listxoatam2 = dstam.pHead.ds.pHead;
                    dstam.pHead = xoa;
                    if (dstam.pHead.ds.pTail == dstam.pHead.ds.pHead) dstam.pHead.ds.pHead = dstam.pHead.ds.pTail = null;
                    else
                    {
                        while (dstam.pHead.ds.pHead != dsxoatam) dstam.pHead.ds.pHead = dstam.pHead.ds.pHead.next;
                        dstam.pHead.ds.pHead.next = null;
                        dstam.pHead.ds.pTail = dstam.pHead.ds.pHead;
                    }
                    dstam.pHead = listxoatam1;
                    dstam.pHead.ds.pHead = listxoatam2;
                    DataGridViewRow index = dgvNHANVIEN.CurrentRow;
                    dgvNHANVIEN.Rows.Remove(index);
                }
                else
                {
                    CH listxoatam1 = dstam.pHead;
                    Linkedlist listxoatam2 = dstam.pHead.ds.pHead;
                    dstam.pHead = xoa;
                    dstam.pHead.ds.pHead = listxoa;
                    Linkedlist muonxoa = dstam.pHead.ds.pHead.next;
                    dstam.pHead.ds.pHead.next = muonxoa.next;
                    muonxoa = new Linkedlist();
                    dstam.pHead = listxoatam1;
                    dstam.pHead.ds.pHead = listxoatam2;
                    DataGridViewRow index = dgvNHANVIEN.CurrentRow;
                    dgvNHANVIEN.Rows.Remove(index);
                }
            }
            dgvNHANVIEN.RefreshEdit();
            if (dstam.pHead.ds.pHead == null)
            {
                txtMANV.Text = "";
                txtHOTEN.Text = "";
                txtNGAYSINH.Text = "";
                cbbMACUAHANG.Text = "";
                txtCHUCVU.Text = "";
                txtTRINHDO.Text = "";
                txtLOAIHINH.Text = "";
                txtGIOITINH.Text = "";
                txtSDT.Text = "";
                txtNGUYENQUAN.Text = "";
                txtDC.Text = "";
                txtCMND.Text = "";
            }
        }

        private void btnLUU_Click(object sender, EventArgs e)
        {
            if (dstam.pHead == null)
            {
                MessageBox.Show("Chưa có cửa hàng!!!", "Cảnh Báo", MessageBoxButtons.OK);
            }
            else
            {
                btnSUA.Enabled = btnXOA.Enabled = btnTHEM.Enabled = true;
                if (flag == "add")
                {
                    CH temp = dstam.pHead;
                    Linkedlist p = new Linkedlist();
                    p.sManhanvien = txtMANV.Text;
                    p.sTennhanvien = txtHOTEN.Text;
                    p.ngaysinh = txtNGAYSINH.Text;
                    p.sChucvu = txtCHUCVU.Text;
                    p.sTrinhdo = txtTRINHDO.Text;
                    p.sLoaihinh = txtLOAIHINH.Text;
                    p.sCMND = txtCMND.Text;
                    p.sGioitinh = txtGIOITINH.Text;
                    p.sSDT = txtSDT.Text;
                    p.sNguyenquan = txtNGUYENQUAN.Text;
                    p.sDC = txtDC.Text;
                    while (temp.sMacuahang != cbbMACUAHANG.Text) temp = temp.next;
                    temp.ds.Addtail(p);
                    dtsv.Rows.Add(p.sManhanvien, p.sTennhanvien, p.ngaysinh, cbbMACUAHANG.Text, p.sChucvu, p.sTrinhdo, p.sLoaihinh, p.sCMND, p.sGioitinh, p.sSDT, p.sNguyenquan, p.sDC);
                    dgvNHANVIEN.DataSource = dtsv;
                    dgvNHANVIEN.RefreshEdit();
                }
                if (flag == "edit")
                {
                    CH listsuatam1 = dstam.pHead;
                    Linkedlist listsuatam2 = dstam.pHead.ds.pHead;
                    dstam.pHead = sua;
                    dstam.pHead.ds.pHead = listsua;
                    dstam.pHead.ds.pHead.sManhanvien = txtMANV.Text;
                    dstam.pHead.ds.pHead.sTennhanvien = txtHOTEN.Text;
                    dstam.pHead.ds.pHead.ngaysinh = txtNGAYSINH.Text;
                    dstam.pHead.ds.pHead.sChucvu = txtCHUCVU.Text;
                    dstam.pHead.ds.pHead.sTrinhdo = txtTRINHDO.Text;
                    dstam.pHead.ds.pHead.sLoaihinh = txtLOAIHINH.Text;
                    dstam.pHead.ds.pHead.sCMND = txtCMND.Text;
                    dstam.pHead.ds.pHead.sGioitinh = txtGIOITINH.Text;
                    dstam.pHead.ds.pHead.sSDT = txtSDT.Text;
                    dstam.pHead.ds.pHead.sNguyenquan = txtNGUYENQUAN.Text;
                    dstam.pHead.ds.pHead.sDC = txtDC.Text;
                    dstam.pHead = listsuatam1;
                    dstam.pHead.ds.pHead = listsuatam2;
                    int index = dgvNHANVIEN.CurrentCell.RowIndex;
                    DataTable dt = (DataTable)dgvNHANVIEN.DataSource;
                    if (dt.Rows.Count > 0)
                    {
                        dgvNHANVIEN.Rows[index].Cells[0].Value = txtMANV.Text;
                        dgvNHANVIEN.Rows[index].Cells[1].Value = txtHOTEN.Text;
                        dgvNHANVIEN.Rows[index].Cells[2].Value = txtNGAYSINH.Text;
                        dgvNHANVIEN.Rows[index].Cells[3].Value = cbbMACUAHANG.Text;
                        dgvNHANVIEN.Rows[index].Cells[4].Value = txtCHUCVU.Text;
                        dgvNHANVIEN.Rows[index].Cells[5].Value = txtTRINHDO.Text;
                        dgvNHANVIEN.Rows[index].Cells[6].Value = txtLOAIHINH.Text;
                        dgvNHANVIEN.Rows[index].Cells[7].Value = txtCMND.Text;
                        dgvNHANVIEN.Rows[index].Cells[8].Value = txtGIOITINH.Text;
                        dgvNHANVIEN.Rows[index].Cells[9].Value = txtSDT.Text;
                        dgvNHANVIEN.Rows[index].Cells[10].Value = txtNGUYENQUAN.Text;
                        dgvNHANVIEN.Rows[index].Cells[11].Value = txtDC.Text;
                    }
                    dgvNHANVIEN.RefreshEdit();
                }
                Block();
            }
        }

        private void dgvNHANVIEN_SelectionChanged(object sender, EventArgs e)
        {

            var cell = dgvNHANVIEN.CurrentCell;
            if (cell != null)
            {
                int index = cell.RowIndex;

                DataTable dt = (DataTable)dgvNHANVIEN.DataSource;
                if (dt != null && dt.Rows.Count > 0)
                {
                    txtMANV.Text = dgvNHANVIEN.Rows[index].Cells[0].Value.ToString();
                    txtHOTEN.Text = dgvNHANVIEN.Rows[index].Cells[1].Value.ToString();
                    txtNGAYSINH.Text = dgvNHANVIEN.Rows[index].Cells[2].Value.ToString();
                    cbbMACUAHANG.Text = dgvNHANVIEN.Rows[index].Cells[3].Value.ToString();
                    txtCHUCVU.Text = dgvNHANVIEN.Rows[index].Cells[4].Value.ToString();
                    txtTRINHDO.Text = dgvNHANVIEN.Rows[index].Cells[5].Value.ToString();
                    txtLOAIHINH.Text = dgvNHANVIEN.Rows[index].Cells[6].Value.ToString();
                    txtCMND.Text = dgvNHANVIEN.Rows[index].Cells[7].Value.ToString();
                    txtGIOITINH.Text = dgvNHANVIEN.Rows[index].Cells[8].Value.ToString();
                    txtSDT.Text = dgvNHANVIEN.Rows[index].Cells[9].Value.ToString();
                    txtNGUYENQUAN.Text = dgvNHANVIEN.Rows[index].Cells[10].Value.ToString();
                    txtDC.Text = dgvNHANVIEN.Rows[index].Cells[11].Value.ToString();
                }
            }
            else
            {
                txtMANV.Text = txtHOTEN.Text = txtNGAYSINH.Text = cbbMACUAHANG.Text = txtCHUCVU.Text = txtTRINHDO.Text = txtLOAIHINH.Text = txtCMND.Text = txtGIOITINH.Text = txtSDT.Text = txtNGUYENQUAN.Text = txtDC.Text = "";
            }
        }

        private void NhanVien_FormClosing(object sender, FormClosingEventArgs e)
        {
           GhiNV();
        }
    }
}
