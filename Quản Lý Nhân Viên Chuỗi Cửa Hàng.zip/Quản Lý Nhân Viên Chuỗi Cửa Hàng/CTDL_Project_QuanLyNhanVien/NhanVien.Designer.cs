﻿namespace CTDL_Project_QuanLyNhanVien
{
    partial class NhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtNGAYSINH = new System.Windows.Forms.TextBox();
            this.txtHOTEN = new System.Windows.Forms.TextBox();
            this.txtMANV = new System.Windows.Forms.TextBox();
            this.lblNGAYSINH = new System.Windows.Forms.Label();
            this.lblHOTEN = new System.Windows.Forms.Label();
            this.lblMANHANVIEN = new System.Windows.Forms.Label();
            this.lblTHONGTIN = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cbbMACUAHANG = new System.Windows.Forms.ComboBox();
            this.txtCMND = new System.Windows.Forms.TextBox();
            this.txtDC = new System.Windows.Forms.TextBox();
            this.txtNGUYENQUAN = new System.Windows.Forms.TextBox();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.txtGIOITINH = new System.Windows.Forms.TextBox();
            this.txtLOAIHINH = new System.Windows.Forms.TextBox();
            this.txtTRINHDO = new System.Windows.Forms.TextBox();
            this.txtCHUCVU = new System.Windows.Forms.TextBox();
            this.lblCMND = new System.Windows.Forms.Label();
            this.lblDC = new System.Windows.Forms.Label();
            this.lblNGUYENQUAN = new System.Windows.Forms.Label();
            this.lblSDT = new System.Windows.Forms.Label();
            this.lblGIOITINH = new System.Windows.Forms.Label();
            this.lblLOAIHINH = new System.Windows.Forms.Label();
            this.lblTRINHDO = new System.Windows.Forms.Label();
            this.lblCHUCVU = new System.Windows.Forms.Label();
            this.lblMACUAHANG = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnXOA = new System.Windows.Forms.Button();
            this.btnLUU = new System.Windows.Forms.Button();
            this.btnSUA = new System.Windows.Forms.Button();
            this.btnTHEM = new System.Windows.Forms.Button();
            this.lblCHUCNANG = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dgvNHANVIEN = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNHANVIEN)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtNGAYSINH);
            this.panel1.Controls.Add(this.txtHOTEN);
            this.panel1.Controls.Add(this.txtMANV);
            this.panel1.Controls.Add(this.lblNGAYSINH);
            this.panel1.Controls.Add(this.lblHOTEN);
            this.panel1.Controls.Add(this.lblMANHANVIEN);
            this.panel1.Controls.Add(this.lblTHONGTIN);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(369, 232);
            this.panel1.TabIndex = 0;
            // 
            // txtNGAYSINH
            // 
            this.txtNGAYSINH.Location = new System.Drawing.Point(153, 98);
            this.txtNGAYSINH.Name = "txtNGAYSINH";
            this.txtNGAYSINH.Size = new System.Drawing.Size(213, 22);
            this.txtNGAYSINH.TabIndex = 19;
            // 
            // txtHOTEN
            // 
            this.txtHOTEN.Location = new System.Drawing.Point(153, 63);
            this.txtHOTEN.Name = "txtHOTEN";
            this.txtHOTEN.Size = new System.Drawing.Size(213, 22);
            this.txtHOTEN.TabIndex = 18;
            // 
            // txtMANV
            // 
            this.txtMANV.Location = new System.Drawing.Point(153, 27);
            this.txtMANV.Name = "txtMANV";
            this.txtMANV.Size = new System.Drawing.Size(213, 22);
            this.txtMANV.TabIndex = 17;
            // 
            // lblNGAYSINH
            // 
            this.lblNGAYSINH.AutoSize = true;
            this.lblNGAYSINH.Location = new System.Drawing.Point(26, 103);
            this.lblNGAYSINH.Name = "lblNGAYSINH";
            this.lblNGAYSINH.Size = new System.Drawing.Size(73, 17);
            this.lblNGAYSINH.TabIndex = 3;
            this.lblNGAYSINH.Text = "Ngày Sinh";
            // 
            // lblHOTEN
            // 
            this.lblHOTEN.AutoSize = true;
            this.lblHOTEN.Location = new System.Drawing.Point(26, 65);
            this.lblHOTEN.Name = "lblHOTEN";
            this.lblHOTEN.Size = new System.Drawing.Size(125, 17);
            this.lblHOTEN.TabIndex = 2;
            this.lblHOTEN.Text = "Họ Tên Nhân Viên";
            // 
            // lblMANHANVIEN
            // 
            this.lblMANHANVIEN.AutoSize = true;
            this.lblMANHANVIEN.Location = new System.Drawing.Point(26, 27);
            this.lblMANHANVIEN.Name = "lblMANHANVIEN";
            this.lblMANHANVIEN.Size = new System.Drawing.Size(97, 17);
            this.lblMANHANVIEN.TabIndex = 1;
            this.lblMANHANVIEN.Text = "Mã Nhân Viên";
            // 
            // lblTHONGTIN
            // 
            this.lblTHONGTIN.AutoSize = true;
            this.lblTHONGTIN.Location = new System.Drawing.Point(3, 0);
            this.lblTHONGTIN.Name = "lblTHONGTIN";
            this.lblTHONGTIN.Size = new System.Drawing.Size(116, 17);
            this.lblTHONGTIN.TabIndex = 0;
            this.lblTHONGTIN.Text = "Thông Tin Hồ Sơ";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.cbbMACUAHANG);
            this.panel2.Controls.Add(this.txtCMND);
            this.panel2.Controls.Add(this.txtDC);
            this.panel2.Controls.Add(this.txtNGUYENQUAN);
            this.panel2.Controls.Add(this.txtSDT);
            this.panel2.Controls.Add(this.txtGIOITINH);
            this.panel2.Controls.Add(this.txtLOAIHINH);
            this.panel2.Controls.Add(this.txtTRINHDO);
            this.panel2.Controls.Add(this.txtCHUCVU);
            this.panel2.Controls.Add(this.lblCMND);
            this.panel2.Controls.Add(this.lblDC);
            this.panel2.Controls.Add(this.lblNGUYENQUAN);
            this.panel2.Controls.Add(this.lblSDT);
            this.panel2.Controls.Add(this.lblGIOITINH);
            this.panel2.Controls.Add(this.lblLOAIHINH);
            this.panel2.Controls.Add(this.lblTRINHDO);
            this.panel2.Controls.Add(this.lblCHUCVU);
            this.panel2.Controls.Add(this.lblMACUAHANG);
            this.panel2.Location = new System.Drawing.Point(387, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(727, 416);
            this.panel2.TabIndex = 1;
            // 
            // cbbMACUAHANG
            // 
            this.cbbMACUAHANG.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbMACUAHANG.Location = new System.Drawing.Point(147, 24);
            this.cbbMACUAHANG.Name = "cbbMACUAHANG";
            this.cbbMACUAHANG.Size = new System.Drawing.Size(238, 24);
            this.cbbMACUAHANG.TabIndex = 32;
            // 
            // txtCMND
            // 
            this.txtCMND.Location = new System.Drawing.Point(147, 182);
            this.txtCMND.Name = "txtCMND";
            this.txtCMND.Size = new System.Drawing.Size(238, 22);
            this.txtCMND.TabIndex = 31;
            // 
            // txtDC
            // 
            this.txtDC.Location = new System.Drawing.Point(496, 136);
            this.txtDC.Multiline = true;
            this.txtDC.Name = "txtDC";
            this.txtDC.Size = new System.Drawing.Size(223, 68);
            this.txtDC.TabIndex = 30;
            // 
            // txtNGUYENQUAN
            // 
            this.txtNGUYENQUAN.Location = new System.Drawing.Point(496, 100);
            this.txtNGUYENQUAN.Name = "txtNGUYENQUAN";
            this.txtNGUYENQUAN.Size = new System.Drawing.Size(223, 22);
            this.txtNGUYENQUAN.TabIndex = 29;
            // 
            // txtSDT
            // 
            this.txtSDT.Location = new System.Drawing.Point(496, 60);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(223, 22);
            this.txtSDT.TabIndex = 28;
            // 
            // txtGIOITINH
            // 
            this.txtGIOITINH.Location = new System.Drawing.Point(496, 22);
            this.txtGIOITINH.Name = "txtGIOITINH";
            this.txtGIOITINH.Size = new System.Drawing.Size(223, 22);
            this.txtGIOITINH.TabIndex = 27;
            // 
            // txtLOAIHINH
            // 
            this.txtLOAIHINH.Location = new System.Drawing.Point(147, 141);
            this.txtLOAIHINH.Name = "txtLOAIHINH";
            this.txtLOAIHINH.Size = new System.Drawing.Size(238, 22);
            this.txtLOAIHINH.TabIndex = 21;
            // 
            // txtTRINHDO
            // 
            this.txtTRINHDO.Location = new System.Drawing.Point(147, 103);
            this.txtTRINHDO.Name = "txtTRINHDO";
            this.txtTRINHDO.Size = new System.Drawing.Size(238, 22);
            this.txtTRINHDO.TabIndex = 20;
            // 
            // txtCHUCVU
            // 
            this.txtCHUCVU.Location = new System.Drawing.Point(147, 65);
            this.txtCHUCVU.Name = "txtCHUCVU";
            this.txtCHUCVU.Size = new System.Drawing.Size(238, 22);
            this.txtCHUCVU.TabIndex = 19;
            // 
            // lblCMND
            // 
            this.lblCMND.AutoSize = true;
            this.lblCMND.Location = new System.Drawing.Point(27, 185);
            this.lblCMND.Name = "lblCMND";
            this.lblCMND.Size = new System.Drawing.Size(81, 17);
            this.lblCMND.TabIndex = 14;
            this.lblCMND.Text = "CMND/CMT";
            // 
            // lblDC
            // 
            this.lblDC.AutoSize = true;
            this.lblDC.Location = new System.Drawing.Point(391, 141);
            this.lblDC.Name = "lblDC";
            this.lblDC.Size = new System.Drawing.Size(106, 17);
            this.lblDC.TabIndex = 13;
            this.lblDC.Text = "ĐC Thường Trú";
            // 
            // lblNGUYENQUAN
            // 
            this.lblNGUYENQUAN.AutoSize = true;
            this.lblNGUYENQUAN.Location = new System.Drawing.Point(393, 103);
            this.lblNGUYENQUAN.Name = "lblNGUYENQUAN";
            this.lblNGUYENQUAN.Size = new System.Drawing.Size(96, 17);
            this.lblNGUYENQUAN.TabIndex = 12;
            this.lblNGUYENQUAN.Text = "Nguyên Quán";
            // 
            // lblSDT
            // 
            this.lblSDT.AutoSize = true;
            this.lblSDT.Location = new System.Drawing.Point(391, 65);
            this.lblSDT.Name = "lblSDT";
            this.lblSDT.Size = new System.Drawing.Size(36, 17);
            this.lblSDT.TabIndex = 11;
            this.lblSDT.Text = "SĐT";
            // 
            // lblGIOITINH
            // 
            this.lblGIOITINH.AutoSize = true;
            this.lblGIOITINH.Location = new System.Drawing.Point(391, 27);
            this.lblGIOITINH.Name = "lblGIOITINH";
            this.lblGIOITINH.Size = new System.Drawing.Size(65, 17);
            this.lblGIOITINH.TabIndex = 10;
            this.lblGIOITINH.Text = "Giới Tính";
            // 
            // lblLOAIHINH
            // 
            this.lblLOAIHINH.AutoSize = true;
            this.lblLOAIHINH.Location = new System.Drawing.Point(27, 141);
            this.lblLOAIHINH.Name = "lblLOAIHINH";
            this.lblLOAIHINH.Size = new System.Drawing.Size(121, 17);
            this.lblLOAIHINH.TabIndex = 4;
            this.lblLOAIHINH.Text = "Loại hình làm việc";
            // 
            // lblTRINHDO
            // 
            this.lblTRINHDO.AutoSize = true;
            this.lblTRINHDO.Location = new System.Drawing.Point(27, 103);
            this.lblTRINHDO.Name = "lblTRINHDO";
            this.lblTRINHDO.Size = new System.Drawing.Size(63, 17);
            this.lblTRINHDO.TabIndex = 3;
            this.lblTRINHDO.Text = "Trình Độ";
            // 
            // lblCHUCVU
            // 
            this.lblCHUCVU.AutoSize = true;
            this.lblCHUCVU.Location = new System.Drawing.Point(27, 65);
            this.lblCHUCVU.Name = "lblCHUCVU";
            this.lblCHUCVU.Size = new System.Drawing.Size(61, 17);
            this.lblCHUCVU.TabIndex = 2;
            this.lblCHUCVU.Text = "Chức Vụ";
            // 
            // lblMACUAHANG
            // 
            this.lblMACUAHANG.AutoSize = true;
            this.lblMACUAHANG.Location = new System.Drawing.Point(27, 27);
            this.lblMACUAHANG.Name = "lblMACUAHANG";
            this.lblMACUAHANG.Size = new System.Drawing.Size(90, 17);
            this.lblMACUAHANG.TabIndex = 1;
            this.lblMACUAHANG.Text = "Mã cửa hàng";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnXOA);
            this.panel3.Controls.Add(this.btnLUU);
            this.panel3.Controls.Add(this.btnSUA);
            this.panel3.Controls.Add(this.btnTHEM);
            this.panel3.Controls.Add(this.lblCHUCNANG);
            this.panel3.Location = new System.Drawing.Point(12, 250);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(369, 178);
            this.panel3.TabIndex = 2;
            // 
            // btnXOA
            // 
            this.btnXOA.Location = new System.Drawing.Point(87, 118);
            this.btnXOA.Name = "btnXOA";
            this.btnXOA.Size = new System.Drawing.Size(109, 31);
            this.btnXOA.TabIndex = 20;
            this.btnXOA.Text = "Xóa";
            this.btnXOA.UseVisualStyleBackColor = true;
            this.btnXOA.Click += new System.EventHandler(this.btnXOA_Click);
            // 
            // btnLUU
            // 
            this.btnLUU.Location = new System.Drawing.Point(222, 118);
            this.btnLUU.Name = "btnLUU";
            this.btnLUU.Size = new System.Drawing.Size(109, 31);
            this.btnLUU.TabIndex = 19;
            this.btnLUU.Text = "Lưu";
            this.btnLUU.UseVisualStyleBackColor = true;
            this.btnLUU.Click += new System.EventHandler(this.btnLUU_Click);
            // 
            // btnSUA
            // 
            this.btnSUA.Location = new System.Drawing.Point(222, 42);
            this.btnSUA.Name = "btnSUA";
            this.btnSUA.Size = new System.Drawing.Size(109, 31);
            this.btnSUA.TabIndex = 18;
            this.btnSUA.Text = "Sửa";
            this.btnSUA.UseVisualStyleBackColor = true;
            this.btnSUA.Click += new System.EventHandler(this.btnSUA_Click);
            // 
            // btnTHEM
            // 
            this.btnTHEM.Location = new System.Drawing.Point(87, 42);
            this.btnTHEM.Name = "btnTHEM";
            this.btnTHEM.Size = new System.Drawing.Size(109, 31);
            this.btnTHEM.TabIndex = 17;
            this.btnTHEM.Text = "Thêm";
            this.btnTHEM.UseVisualStyleBackColor = true;
            this.btnTHEM.Click += new System.EventHandler(this.btnTHEM_Click);
            // 
            // lblCHUCNANG
            // 
            this.lblCHUCNANG.AutoSize = true;
            this.lblCHUCNANG.Location = new System.Drawing.Point(3, 15);
            this.lblCHUCNANG.Name = "lblCHUCNANG";
            this.lblCHUCNANG.Size = new System.Drawing.Size(78, 17);
            this.lblCHUCNANG.TabIndex = 17;
            this.lblCHUCNANG.Text = "Chức Năng";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.dgvNHANVIEN);
            this.panel4.Location = new System.Drawing.Point(12, 434);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1102, 230);
            this.panel4.TabIndex = 3;
            // 
            // dgvNHANVIEN
            // 
            this.dgvNHANVIEN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNHANVIEN.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column8,
            this.Column6,
            this.Column9,
            this.Column7,
            this.Column10,
            this.Column11,
            this.Column12});
            this.dgvNHANVIEN.Location = new System.Drawing.Point(0, 0);
            this.dgvNHANVIEN.Name = "dgvNHANVIEN";
            this.dgvNHANVIEN.RowTemplate.Height = 24;
            this.dgvNHANVIEN.Size = new System.Drawing.Size(1099, 224);
            this.dgvNHANVIEN.TabIndex = 0;
            this.dgvNHANVIEN.SelectionChanged += new System.EventHandler(this.dgvNHANVIEN_SelectionChanged);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Mã nhân viên";
            this.Column1.Frozen = true;
            this.Column1.HeaderText = "Mã nhân viên";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "Họ và tên";
            this.Column2.HeaderText = "Họ và tên";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 300;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "Ngày sinh";
            this.Column3.HeaderText = "Ngày sinh";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 150;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "Mã cửa hàng";
            this.Column4.HeaderText = "Mã cửa hàng";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 150;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "Chức vụ";
            this.Column5.HeaderText = "Chức vụ";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 150;
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "Trình Độ";
            this.Column8.HeaderText = "Trình Độ";
            this.Column8.Name = "Column8";
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "Loại hình";
            this.Column6.HeaderText = "Loại hình";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "CMND/CMT";
            this.Column9.HeaderText = "CMND/CMT";
            this.Column9.Name = "Column9";
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "Giới tính";
            this.Column7.HeaderText = "Giới tính";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "SĐT";
            this.Column10.HeaderText = "SĐT";
            this.Column10.Name = "Column10";
            // 
            // Column11
            // 
            this.Column11.DataPropertyName = "Nguyên Quán";
            this.Column11.HeaderText = "Nguyên Quán";
            this.Column11.Name = "Column11";
            // 
            // Column12
            // 
            this.Column12.DataPropertyName = "ĐC Thường Trú";
            this.Column12.HeaderText = "ĐC Thường Trú";
            this.Column12.Name = "Column12";
            // 
            // panel5
            // 
            this.panel5.Location = new System.Drawing.Point(12, 667);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1102, 23);
            this.panel5.TabIndex = 4;
            // 
            // NhanVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1132, 704);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "NhanVien";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hồ sơ nhân viên";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.NhanVien_FormClosing);
            this.Load += new System.EventHandler(this.NhanVien_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNHANVIEN)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblNGAYSINH;
        private System.Windows.Forms.Label lblHOTEN;
        private System.Windows.Forms.Label lblMANHANVIEN;
        private System.Windows.Forms.Label lblTHONGTIN;
        private System.Windows.Forms.Label lblLOAIHINH;
        private System.Windows.Forms.Label lblTRINHDO;
        private System.Windows.Forms.Label lblCHUCVU;
        private System.Windows.Forms.Label lblMACUAHANG;
        private System.Windows.Forms.Label lblCMND;
        private System.Windows.Forms.Label lblDC;
        private System.Windows.Forms.Label lblNGUYENQUAN;
        private System.Windows.Forms.Label lblSDT;
        private System.Windows.Forms.Label lblGIOITINH;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnXOA;
        private System.Windows.Forms.Button btnLUU;
        private System.Windows.Forms.Button btnSUA;
        private System.Windows.Forms.Button btnTHEM;
        private System.Windows.Forms.Label lblCHUCNANG;
        private System.Windows.Forms.TextBox txtNGAYSINH;
        private System.Windows.Forms.TextBox txtHOTEN;
        private System.Windows.Forms.TextBox txtMANV;
        private System.Windows.Forms.TextBox txtCMND;
        private System.Windows.Forms.TextBox txtDC;
        private System.Windows.Forms.TextBox txtNGUYENQUAN;
        private System.Windows.Forms.TextBox txtSDT;
        private System.Windows.Forms.TextBox txtGIOITINH;
        private System.Windows.Forms.TextBox txtLOAIHINH;
        private System.Windows.Forms.TextBox txtTRINHDO;
        private System.Windows.Forms.TextBox txtCHUCVU;
        private System.Windows.Forms.DataGridView dgvNHANVIEN;
        private System.Windows.Forms.ComboBox cbbMACUAHANG;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
    }
}