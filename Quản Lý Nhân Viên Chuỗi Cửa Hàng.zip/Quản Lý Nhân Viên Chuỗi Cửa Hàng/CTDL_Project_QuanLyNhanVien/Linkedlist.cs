﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTDL_Project_QuanLyNhanVien
{
    public class Linkedlist
    {
        public string sManhanvien;
        public string sTennhanvien;
        public string ngaysinh;
        public string sChucvu;
        public string sTrinhdo;
        public string sLoaihinh;
        public string sCMND;
        public string sGioitinh;
        public string sSDT;
        public string sNguyenquan;
        public string sDC;
        public Linkedlist next = null;
        public Linkedlist pHead;
        public Linkedlist pTail;
        public Linkedlist()
        {
            pHead = pTail = null;
        }
        public void Addhead(Linkedlist p)
        {
            if (pHead == null)            //list rỗng
            {
                pHead = p;
                pTail = p;
            }
            else
            {
                p.next = pHead;
                pHead = p;
            }
        }
        public void Addtail(Linkedlist p)
        {
            if (pHead == null)            //list rỗng
            {
                pHead = p;
                pTail = p;
            }
            else
            {
                pTail.next = p;
                pTail = p;
            }
        }
        public void Removehead()
        {
            pHead = pHead.next;
        }
        public void Removetail()
        {
            if (pHead != null)
            {
                if (pHead == pTail)
                {
                    pHead = pTail = null;
                    return;
                }
                Linkedlist tam = pHead;
                while (tam.next != pTail) tam = tam.next;
                tam.next = null;
                pTail = tam;
            }
        }
    }
    public class CH
    {
        public string sMacuahang;
        public string sSDTCH;
        public string sDiachi;
        public CH next = null;
        public Linkedlist ds = new Linkedlist();
    }
    public class List
    {
        public CH pHead;
        public CH pTail;
        public List()
        {
            pHead = pTail = null;       //khởi tạo
        }
        public void Addhead(CH p)
        {
            if (pHead == null)            //list rỗng
            {
                pHead = p;
                pTail = p;
            }
            else
            {
                p.next = pHead;
                pHead = p;
            }
        }
        public void Addtail(CH p)
        {
            if (pHead == null)            //list rỗng
            {
                pHead = p;
                pTail = p;
            }
            else
            {
                pTail.next = p;
                pTail = p;
            }
        }
        public void Removehead()
        {
            pHead = pHead.next;
        }
        public void Removetail()
        {
            if (pHead != null)
            {
                if (pHead == pTail)
                {
                    pHead = pTail = null;
                    return;
                }
                CH tam = pHead;
                while (tam.next != pTail) tam = tam.next;
                tam.next = null;
                pTail = tam;
            }
        }
        public void Xuat()
        {
            if (pHead != null)
            {
                CH p = pHead;
                while (p != null)
                {
                    Console.WriteLine(p.sMacuahang + " ");
                    p = p.next;
                }
            }
        }
    }
}
