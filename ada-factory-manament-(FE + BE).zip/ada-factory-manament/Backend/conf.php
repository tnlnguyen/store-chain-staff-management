<?php 
define('hostname', 'localhost');
define('dbuser', 'root');
define('dbpass', '');
define('dbname', 'store');
?>