<?php 
require 'connection.php';
require 'restful_api.php';
/**
 * summary
 */
class user_controller extends restful_api
{
    private $db;
    private $connection;
    public function __construct() {
        $this->db = new DB_connection();
        $this->connection = $this->db->get_connection();
        parent::__construct();
    }
    function login_request() {
        $username = $this->params['username'];
        $password = $this->params['password'];
        $query = "SELECT * FROM users WHERE username = '".$username."' AND password  = '".$password."'";
    	$result = mysqli_query($this->connection, $query);
    	if (mysqli_num_rows($result) == 1) {
            mysqli_close($this->connection);
            header('Location: http://localhost/ada-factory-manament/index.html');
            echo 'hi';
    		return $this->response(200);
    	}
    	else {
            mysqli_close($this->connection);
            return $this->response(400);
    	}
    }
    function getUserbyId() {
        $user = $_GET['id'];
        if (isset($user)) {
            $query = "SELECT * FROM users WHERE id = '".$user."'";
            $result = mysqli_query($this->connection, $query);
            if (mysqli_num_rows($result) == 1) {
                $json_arr = array();
                while ($row = mysqli_fetch_assoc($result)) {
                    if (isset($row['picture'])) {
                        //chuyen doi kieu blob sang base64
                        $img_temp = $row['picture'];
                        $row['picture'] = base64_encode($img_temp);
                    }
                    $json_arr[] = $row;
                }
                if (isset($json_arr)) {
                    return $this->response(200, $json_arr);
                }
            }
        }
        return $this->response(404);
    }
}
$user_api = new user_controller();
?>