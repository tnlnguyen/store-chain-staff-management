var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
};
function setTitle(id) {
    document.title = id;
}
function format_curency(money) {
    money = money.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");
    return money;  
};
function Buildlist(data) {
    //create rowtop
    div_top = document.createElement('div');
    div_rate = document.createElement('div');
    div_likeshare = document.createElement('div');
    h1_name = document.createElement('h1');

    h1_name.textContent = data[0].mota;
    div_rate.className = 'ratingresult';
    div_likeshare.className = 'likeshare';
    div_top.className = 'rowtop';

    div_top.append(h1_name);
    div_top.append(div_rate);
    div_top.append(div_likeshare);

    //create hor line
    hr_line = document.createElement('hr');
    hr_line.color = 'black';
    hr_line.size = 1;

    //create rowdetail
    div_rowdetail = document.createElement('div');
    img = document.createElement('img');
    img.setAttribute('src',`data:image/png;base64,${data[0].hinhanh}`);
    div_price = document.createElement('div');
    div_product_detail = document.createElement('div');
    div_detail = document.createElement('div');
    div_detail1 = document.createElement('div');
    div_detail2 = document.createElement('div');
    div_detail3 = document.createElement('div');
    h1_mathietbi = document.createElement('h1');
    h1_mahoa = document.createElement('h1');
    h1_tenthietbi = document.createElement('h1');
    h1_nhasx = document.createElement('h1');
    h1_sl_tonkho_min = document.createElement('h1');
    h1_sl_tonkho_max = document.createElement('h1');
    h1_sl_hienhuu = document.createElement('h1');
    h1_tonggiatri = document.createElement('h1');
    h1_vt_sudung = document.createElement('h1');
    h1_vt_kho = document.createElement('h1');
    h1_lichsu_nhap = document.createElement('h1');
    h1_tg_giao = document.createElement('h1');
    div_dinhkem = document.createElement('div');
    h1_tailieu = document.createElement('h1');
    h1_cachthucmua = document.createElement('h1');

    div_rowdetail.className = 'rowdetail';
    div_product_detail.className = 'product-detail';
    div_price.className = 'price';
    div_detail.className = 'detail';
    div_detail1.className = 'detail-1';
    div_detail2.className = 'detail-2';
    div_detail3.className = 'detail-3';
    div_dinhkem.className = 'dinhkem';

    div_price.textContent =format_curency(data[0].dongianhapkho) + ' VND';
    h1_mathietbi.textContent ='Mã thiết bị: ' + data[0].mathietbi;
    h1_mahoa.textContent ='Mã hóa thiết bị: ' + data[0].mahoa;
    h1_tenthietbi.textContent ='Tên thiết bị: ' + data[0].tenthietbi;
    h1_nhasx.textContent ='Nhà sản xuất: ' + data[0].nhasx;
    h1_sl_tonkho_min.textContent ='Số lượng tồn kho nhỏ nhất: ' + data[0].sl_tonkho_min;
    h1_sl_tonkho_max.textContent ='Số lượng tồn kho lớn nhất: ' + data[0].sl_tonkho_max;
    h1_sl_hienhuu.textContent ='Số lượng hiện hữu: ' + data[0].sl_hienhuu;
    h1_tonggiatri.textContent ='Tổng giá trị: ' + format_curency(data[0].tonggiatri) + ' VND';
    h1_vt_sudung.textContent ='Vị trí sử dụng: ' + data[0].vt_sudung;
    h1_vt_kho.textContent ='Vị trí kho: ' + data[0].vt_kho;
    h1_lichsu_nhap.textContent ='Lịch sử nhập: ' + data[0].lichsu_nhap;
    h1_tg_giao.textContent ='Thời gian giao: ' + data[0].tg_giao;
    h1_tailieu.textContent ='Tài liệu đính kèm: ' + data[0].tailieu;
    h1_cachthucmua.textContent ='Cách thức mua: ' + data[0].cachthucmua;


    div_detail1.append(h1_mathietbi);
    div_detail1.append(h1_mahoa);
    div_detail1.append(h1_tenthietbi);
    div_detail1.append(h1_nhasx);

    div_detail2.append(h1_sl_tonkho_min);
    div_detail2.append(h1_sl_tonkho_max);
    div_detail2.append(h1_sl_hienhuu);
    div_detail2.append(h1_tonggiatri);

    div_detail3.append(h1_vt_sudung);
    div_detail3.append(h1_vt_kho);
    div_detail3.append(h1_lichsu_nhap);
    div_detail3.append(h1_tg_giao);
    
    div_dinhkem.append(h1_tailieu);
    div_dinhkem.append(h1_cachthucmua);

    div_detail.append(div_detail1);
    div_detail.append(div_detail2);
    div_detail.append(div_detail3);
    
    div_product_detail.append(div_price);
    div_product_detail.append(div_detail);
    div_product_detail.append(div_dinhkem);

    div_rowdetail.append(img);
    div_rowdetail.append(div_product_detail);

    document.getElementById("gridview").appendChild(div_top);
    document.getElementById("gridview").appendChild(hr_line);
    document.getElementById("gridview").appendChild(div_rowdetail);
}
function getData() {
    var id = getUrlParameter('id');
    $(document).ready(function() {
        $.ajax({
            url: `http://localhost/ada-factory-manament/Backend/data_controller.php/getDatabyId/?mathietbi=${id}`,
            method: 'GET',
            success: function (data) {
                    console.log(data);
                    setTitle(data[0].mota);
                    Buildlist(data);
            }
        })
    })
}
setTitle();
getData();