function getData() {
    $(document).ready(function() {
        $.ajax({
            url: 'http://localhost/ada-factory-manament/Backend/data_controller.php/getData/',
            method: 'GET',
            success: function (data) {
                    console.log(data);
                    //buildData(data);
                    Buildlist(data);
            }
        })
    })
}
function buildData(data) {
    for (var i = 0; i <data.length;i++) {
        var new_tr = document.createElement('tr');
        var new_mathietbi_td = document.createElement('td');
        var new_mahoa_td = document.createElement('td');
        var new_tenthietbi_td = document.createElement('td');
        var new_mota_td = document.createElement('td');
        var new_nhasx_td = document.createElement('td');

        var new_dongianhapkho_td = document.createElement('td');
        var new_sl_tonkho_min_td = document.createElement('td');
        var new_sl_tonkho_max_td = document.createElement('td');
        var new_sl_hienhuu_td = document.createElement('td');
        var new_donvitinh_td = document.createElement('td');
        var new_tonggiatri_td = document.createElement('td');

        var new_vt_sudung_td = document.createElement('td');
        var new_vt_kho_td = document.createElement('td');
        var new_lichsu_nhap_td = document.createElement('td');
        var new_tg_giao_td = document.createElement('td');
        var new_tailieu_td = document.createElement('td');
        var new_hinhanh_td = document.createElement('td');
        var new_cachthucmua_td = document.createElement('td')

        new_mathietbi_td.innerHTML = data[i].mathietbi;
        new_mahoa_td.innerHTML = data[i].mahoa;
        new_tenthietbi_td.innerHTML = data[i].tenthietbi;
        new_mota_td.innerHTML = data[i].mota;
        new_nhasx_td.innerHTML = data[i].nhasx;

        new_dongianhapkho_td.innerHTML = data[i].dongianhapkho;
        new_sl_tonkho_min_td.innerHTML = data[i].sl_tonkho_min;
        new_sl_tonkho_max_td.innerHTML = data[i].sl_tonkho_max;
        new_sl_hienhuu_td.innerHTML = data[i].sl_hienhuu;
        new_donvitinh_td.innerHTML = data[i].donvitinh;
        new_tonggiatri_td.innerHTML = data[i].tonggiatri;

        new_vt_sudung_td.innerHTML = data[i].vt_sudung;
        new_vt_kho_td.innerHTML = data[i].vt_kho;
        new_lichsu_nhap_td.innerHTML = data[i].lichsu_nhap;
        new_tg_giao_td.innerHTML = moment(data[i].tg_giao).format('DD.MM.YYYY HH:mm');
        new_tailieu_td.innerHTML = data[i].tailieu;
        new_hinhanh_td.innerHTML = `<img src="data:image/png;base64,${data[i].hinhanh}" />`;
        new_cachthucmua_td.innerHTML = data[i].cachthucmua;

        new_tr.append(new_mathietbi_td);
        new_tr.append(new_mahoa_td);
        new_tr.append(new_tenthietbi_td);
        new_tr.append(new_mota_td);
        new_tr.append(new_nhasx_td);

        new_tr.append(new_dongianhapkho_td);
        new_tr.append(new_sl_tonkho_min_td);
        new_tr.append(new_sl_tonkho_max_td);
        new_tr.append(new_sl_hienhuu_td);
        new_tr.append(new_donvitinh_td);
        new_tr.append(new_tonggiatri_td);

        new_tr.append(new_vt_sudung_td);
        new_tr.append(new_vt_kho_td);
        new_tr.append(new_lichsu_nhap_td);
        new_tr.append(new_tg_giao_td);
        new_tr.append(new_tailieu_td);
        new_tr.append(new_hinhanh_td);
        new_tr.append(new_cachthucmua_td);

        document.getElementById("datatable").appendChild(new_tr);

    }
}
function Buildlist(data) {
    for (var i = 0; i < data.length; i++) {
        new_div = document.createElement('div');
        new_img = document.createElement('img');
        new_p = document.createElement('p');
        new_button = document.createElement('button');

        new_div.className = "div";
        new_img.setAttribute('src',`data:image/png;base64,${data[i].hinhanh}`);
        new_p.textContent = data[i].mota;
        new_button.textContent = "Xem chi tiết";

        new_div.append(new_img);
        new_div.append(new_p);
        new_div.append(new_button);

        document.getElementById("gridview").appendChild(new_div);
    }
}
getData();