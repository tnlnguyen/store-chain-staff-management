function getData() {
    $(document).ready(function() {
        $.ajax({
            url: 'http://localhost/ada-factory-manament/Backend/data_controller.php/getData/',
            method: 'GET',
            success: function (data) {
                    console.log(data);
                    Buildlist(data);
            }
        })
    })
}
function Buildlist(data) {
    for (var i = 0; i < data.length; i++) {
        new_div = document.createElement('div');
        new_img = document.createElement('img');
        new_p = document.createElement('p');
        new_button = document.createElement('button');
        new_a = document.createElement('a');

        new_div.className = "div";
        new_img.setAttribute('src',`data:image/png;base64,${data[i].hinhanh}`);
        new_p.textContent = data[i].mota;
        new_p.className = "title-name";
        new_button.textContent = "Xem chi tiết";
        new_button.className = "chi-tiet-button";
        new_a.href = `chi-tiet-san-pham.html?id=${data[i].mathietbi}`;
        new_a.append(new_button);

        new_div.append(new_img);
        new_div.append(new_p);
        new_div.append(new_a);

        document.getElementById("gridview").appendChild(new_div);
    }
}
getData();
