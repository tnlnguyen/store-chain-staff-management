<?php
require 'connection.php';
require 'restful_api.php';
/**
 * summary
 */
class data_controller extends restful_api {
    
    private $db;
    private $connection;
    private $query = "SELECT sp.mathietbi ,sp.mahoa , sp.tenthietbi , sp.mota , sp.nhasx,
                        spa.dongianhapkho , spa.sl_tonkho_min , spa.sl_tonkho_max, spa.sl_hienhuu, spa.donvitinh, spa.tonggiatri, 
                        spi.vt_sudung, spi.vt_kho, spi.lichsu_nhap,spi.tg_giao, spi.tailieu, spi.hinhanh, spi.cachthucmua
                        FROM sanpham as sp INNER JOIN sanpham_amount as spa on sp.mathietbi = spa.mathietbi INNER JOIN sanpham_info as spi on sp.mathietbi = spi.mathietbi";

    public function __construct() {
        $this->db = new DB_connection();
        $this->connection = $this->db->get_connection();
        parent::__construct();
    }
    function data_request() {
        //params for tab sanpham
        $mathietbi = $_GET['mathietbi'];
        $mahoa = $_GET['mahoa'];
        $tenthietbi = $_GET['tenthietbi'];
        $mota = $_GET['mota'];
        $nhasx = $_GET['nhasx'];
        //params for tab sanpham_amount
        $dongianhapkho = $_GET['dongianhapkho'];
        $sl_tonkho_min = $_GET['sl_tonkho_min'];
        $sl_tonkho_max = $_GET['sl_tonkho_max'];
        $sl_hienhuu = $_GET['sl_hienhuu'];
        $donvitinh = $_GET['donvitinh'];
        $tonggiatri = $_GET['tonggiatri'];
        //params for tab sanpham_info
        $vt_sudung = $_GET['vt_sudung'];
        $vt_kho = $_GET['vt_kho'];
        $lichsu_nhap = $_GET['lichsu_nhap'];
        $tg_giao = $_GET['tg_giao'];
        $tailieu = $_GET['tailieu'];
        $hinhanh = $_GET['hinhanh'];
        $cachthucmua = $_GET['cachthucmua'];

        
    }
    function getData() {
        //join query
        $result = mysqli_query($this->connection, $this->query);
        $json_arr = array();
        while ($row = mysqli_fetch_assoc($result)) {
            if (isset($row['hinhanh'])) {
                //chuyen doi kieu blob sang base64
                $img_temp = $row['hinhanh'];
                $row['hinhanh'] = base64_encode($img_temp);
            }
            $json_arr[] = $row;
        }
        if (isset($json_arr)) {
            return $this->response(200, $json_arr);
        }
        return $this->response(404);
    }
    function getDatabyId() {
        $mathietbi = $_GET['mathietbi'];
        if (isset($mathietbi)) {
            $final_query = $this->query. " where sp.mathietbi = '".$mathietbi."'";
            $result = mysqli_query($this->connection, $final_query);
            $json_arr = array();
            while ($row = mysqli_fetch_assoc($result)) {
                if (isset($row['hinhanh'])) {
                    //chuyen doi kieu blob sang base64
                    $img_temp = $row['hinhanh'];
                    $row['hinhanh'] = base64_encode($img_temp);
                }
                $json_arr[] = $row;
            }
            if (isset($json_arr)) {
                return $this->response(200, $json_arr);
            }
            return $this->response(404);
        }
        return $this->response(404);
    }
}
$data = new data_controller();
?>