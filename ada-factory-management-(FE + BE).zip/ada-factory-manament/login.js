function login() {
    document.getElementsByClassName("btn-grad").click(function() {
        alert('hi');
    })
}